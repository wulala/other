import { Text, View } from '@tarojs/components'
import { inject, observer } from '@tarojs/mobx'
import { Component } from '@tarojs/taro'




@inject('counterStore')
@observer
class Index extends Component {

  config = {
    navigationBarTitleText: '内页'
  }

  render() {

    return (
      <View className='index'>
        <Text> 我是内页 </Text>

        <View><Text>请在当前页点击“刷新”，然后返回上一页页面</Text></View>

      </View>
    )
  }
}

export default Index
