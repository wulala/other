import { Button, Text, View } from '@tarojs/components'
import { inject, observer } from '@tarojs/mobx'
import Taro, { Component } from '@tarojs/taro'




@inject('counterStore')
@observer
class Index extends Component {

  config = {
    navigationBarTitleText: '首页'
  }

  go() {
    // 跳转到目的页面，打开新页面
    Taro.navigateTo({
      url: '/pages/sub/index'
    })
  }

  render() {

    return (
      <View className='index'>

        <View><Text>taro: v2.2.5</Text></View>

        <Text>我是首页， 请点击跳转到内页</Text>

        <Button onClick={this.go}>跳转到内页</Button>

        <View><Text>如果在“内页”刷新后返回到当前页， 此时你点击 tab栏的“用户” ，是没有效果的（实际上创建了两个tabBar页面，请在切换“用户”页面后往下滑动查看。↓↓↓↓↓↓）</Text></View>






      </View>
    )
  }
}

export default Index
