import { Text, View } from '@tarojs/components'
import { inject, observer } from '@tarojs/mobx'
import { Component } from '@tarojs/taro'




@inject('counterStore')
@observer
class Index extends Component {

  config = {
    navigationBarTitleText: '用户'
  }

  render() {

    return (
      <View className='index'>
        <Text> 我是用户 </Text>
      </View>
    )
  }
}

export default Index
